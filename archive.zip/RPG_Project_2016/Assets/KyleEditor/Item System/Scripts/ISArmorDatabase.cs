﻿// Kyle Bull
// RPG Project 2016
// Item System

using UnityEngine;
using UnityEditor;
using System.Collections;


namespace KyleBull.ItemSystem
{
    public class ISArmorDatabase : ScriptableObjectDatabase<ISArmor>
    {

    }
}
